</<!DOCTYPE html>
<html>
<head>
 
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.2/css/bulma.css">
    
 
</head>
 
<body>
 
    <div class="container">
        @yield('content')
    </div>    
 
</html>