 
<?php $__env->startSection('content'); ?>
 
</<!DOCTYPE html>
<html>
<head>
   
</head>
<style>


</style>
<body>
 <br>
<h1 class="title">Players Table</h1>

<form action="/players/create">
    <div class="field">
        <div class="control">
           <button type="submit" class="button is-link" >Create New Player</button>
      </div>
   </div>
</form>

 
<?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li> 
    <a href="/players/<?php echo e($player->id); ?>">
 
    <?php echo e($player->name); ?>  
 
    </a>
 
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
 
</body>
</html>
 
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /Users/hardikparsania_mac/Desktop/web_demonuts/lara5.8Crud/lara5.8Crud/resources/views/players/index.blade.php */ ?>