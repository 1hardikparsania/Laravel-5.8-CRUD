 
<?php $__env->startSection('content'); ?>
 
    <h1 class="title"> Edit Players </h1>
 
    <form method="POST" action="/players/<?php echo e($players->id); ?>">
 
    <?php echo method_field('PATCH'); ?>
    <?php echo csrf_field(); ?>
 
 
        <div class="field">
 
            <label class="lable" for="name">Name </label>
 
            <div class="control">
 
                <input type="text" class="input" name="name" placeholder="Title" value="<?php echo e($players->name); ?>" required>
        
            </div>
       
        </div>
 
        <div class="field">
 
                <label class="lable" for="sport">Sport </label>
 
                <div class="control">
 
                      <textarea class="textarea" name="sport" required><?php echo e($players->sport); ?> </textarea>
 
                </div>
 
        </div>
        <div class="field">
 
             <label class="lable" for="country">Country </label>

            <div class="control">

                 <input type="text" class="input" name="country" placeholder="Title" value="<?php echo e($players->country); ?>" required>

           </div>

        </div>
 
        <div class="field">
 
            <div class="control">
 
                <button type="submit" class="button is-link">Update Player</button>
 
            </div>
 
        </div>
 
    </form>  
 
    <form method="POST" action="/players/<?php echo e($players->id); ?>">
 
    <?php echo method_field('DELETE'); ?>
    <?php echo csrf_field(); ?>
 
 
        <div class="field">
 
            <div class="control">
 
                <button type="submit" class="button is-link">Delete Player</button>
 
            </div>
 
        </div>         
 
    </form>
 
 
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /Users/hardikparsania_mac/Desktop/web_demonuts/lara5.8Crud/lara5.8Crud/resources/views/players/edit.blade.php */ ?>